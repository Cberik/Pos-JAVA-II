package br.edu.utfpr;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

public class CotadorDeMoedas {

    public Path verificarEntrada() {

        Path entrada = Path.of("entrada", "moedas.txt");

        if (!Files.exists(entrada)) {
            System.err.println("Erro: arquivo de entrada não encontrado.");
            System.exit(1);
        }

        return entrada;
    }

    public Path verificarSaida() {

        Path diretorio = Path.of("saida");

        try {

            Files.createDirectories(diretorio);
        } catch (IOException e) {
            System.err.println("Erro ao criar o diretório de saída.");
            System.exit(1);
        }

        return diretorio.resolve("cotacoes.csv");
    }

    public List<String> lerArquivoDeMoedas(Path entrada) {

        try {

            if (!Files.exists(entrada)) {
                return List.of();
            }
            return Files.readAllLines(entrada)
                    .stream()
                    .map(String::trim)
                    .map(String::toUpperCase)
                    .filter(moeda -> moeda.matches("[A-Z]{3}"))
                    .toList();

        } catch (IOException e) {
            System.err.println("Erro ao ler o arquivo de moedas.");

            return List.of();
        }

    }

    public void cotarERegistrar(Path saida, List<String> moedas, ClienteCambio cliente) {

        if (moedas.isEmpty()) {
            return;
        }

        List<CompletableFuture<Optional<Cotacao>>> consultas = moedas.stream()
                .map(cliente::consultar)
                .toList();

        CompletableFuture.allOf(
                consultas.toArray(new CompletableFuture[0])
        ).join();

        List<Cotacao> cotacoes = consultas.stream()
                .map(CompletableFuture::join)
                .filter(Optional::isPresent)
                .map(Optional::get)
                .toList();

        gravarEmCSV(saida, cotacoes);
    }

    private void gravarEmCSV(Path saida, List<Cotacao> cotacoes) {

        try {

            List<String> linhas = cotacoes.stream()
                    .map(Cotacao::paraCsv)
                    .toList();

            linhas = new java.util.ArrayList<>(linhas);
            linhas.add(0, "moeda,valor,coletadoEm");

            String conteudo = String.join("\n", linhas);

            Files.writeString(
                    saida,
                    conteudo,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING,
                    StandardOpenOption.WRITE
            );

        } catch (IOException e) {
            System.err.println("Erro ao gravar o arquivo CSV.");
            throw new RuntimeException("Falha na escrita do CSV", e);
        }
    }
}
